<p align="center">
  <img src="PANDITHAN/Evil-Inside.jpeg" alt="Evil-Inside Logo">
</p>
<h1 align="center">
  <b>Evil-Inside</b>
</h1>

DEMO BOT - [Evil-Inside](https://telegram.dog/Evil_Inside_robot)
 

Hello i am TELEGRAM GROUP MANAGEMENT BOT MY NAME IS Evil-Inside ⚡ i have both amazing modules

<h3 align="center">ℂ𝕆ℕ𝕋𝔸ℂ𝕋 𝕄𝔼 𝕆ℕ<img align="center" src="https://github.com/PANDITHAN/PANDITHAN/blob/main/assets/Handshake.gif" height="33px" /></h3>
<p align="center">
<a href="https://telegram.dog/PANDITHAN_SIR"><img alt="Telegram" src="https://img.shields.io/badge/𝙿𝚁𝙾𝙵𝙸𝙻𝙴-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white"/></a>
<a href="https://telegram.dog/M_STER_TECH"><img alt="Telegram" src="https://img.shields.io/badge/𝙲𝙷𝙰𝙽𝙽𝙴𝙻-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white"/></a>
</p>



# 𝐅𝐞𝐚𝐭𝐮𝐫𝐞𝐬
* Admin
* AFK
* Anti Flood
* Backup
* Ban
* Bios & About
* Break The Chain
* Biuetext Cleaning
* Cas
* Chat Bot With Kuki api key. 
* Command Disabling
* Connection
* Covid 19 Tracker
* Covid 19 Virus
* Currency Converter
* Dev Promoter
* Dictionary
* Disasters
* Dog Bin
* Federation
* Filters
* Fun
* Github
* Global Ban
* Global Mute
* GPS
* Grammer
* Greetings
* Image Search
* Locks

# 𝐇𝐎𝐖 𝐓𝐎 𝐃𝐄𝐏𝐋𝐎𝐘 
<p align="center">
<a href="https://youtu.be/Bz8AUvN5bSo"><img <a href="https://github.com/PANDITHAN"><img src="https://github.com/PANDITHAN/VEDIO-BUTTON/blob/main/BUTTON/BUTTON_POWERED_BY-M-STER.png" alt="PANDITHAN" border="0" height="40" width="200" align="center" /></a>
</p>


# 𝐃𝐞𝐩𝐥𝐨𝐲 𝐓𝐨 𝐇𝐞𝐫𝐨𝐤𝐮
<p align="center">
<a href="https://dashboard.heroku.com/new?button-url=https%3A%2F%2Fgithub.com%2Flegendx22%2FGRANDROBOT&template=hhttps://github.com/PANDITHAN/Evil-Inside"><img src="https://github.com/PR0FESS0R-99/Buttons/blob/Professor-99/heroku/herokudeploy-01.svg" alt="PR0FESS0R-99" border="0" height="125" width="200" align="center" /></a>
</p>
 
# 𝐂𝐨𝐧𝐟𝐢𝐠 𝐕𝐚𝐫𝐬


- `AI_API_KEY` : for activate chatbot {`x_y_z`} & Remember One Thing Coffeehouse API key Is No more Use Kuki chat bot. No need of taking Kuki api key we have already added a api key of ours. 

- `ALLOW_EXCL` : Set this to True if you want ! to be a command prefix along with / {`True`}

- `API_OPENWEATHER` : Required for weather information {`5c5adc2bc1832de6943e3f4467e84c39`}

- `BAN_STICKER ` : ID of the sticker you want to use when banning people from @MT_ID_Bot

- `CASH_API_KEY` : Required for currency converter {`-xyz`}

- `DEL_CMDS` : Set this to True if you want to delete command messages from users who don't have the perms to run that command. {`True`}

- `DEV_USERS` : ID of users who are Dev (can use /py etc.) from @MT_ID_Bot

- `ENV` : Setting this to ANYTHING will enable environment variables. {`ANYTHING`}

- `GBAN_LOGS` Gban log channel, include the hyphen too: ex: -100××××× {`-123`}

- `START_PIC` : Image shows when hit, users can can multiple photospace,pliting photo with space, togetpic: /start {`@MT_TelegraPH_Bot`}

- `OWNER_ID` : Your user ID as an integer. from @MT_ID_Bot

- `OWNER_NAME` Your username {`PANDITHAN`}

- `PORT` : Port to use for your webhooks.

- `SQLALCHEMY_DATABASE_URI` : Your postgres sql db, empty this field if you dont have one. {`sqldbtype://username:pw@hostname:port/db_name`}

- `STRICT_GBAN` : Enforce gbans across new groups as well as old groups. When a gbanned user talks, he will be banned. {`True`}

- `SUDO_USERS` : A space separated list of user IDs who you want to assign as sudo users.

- `TIGER_USERS` : A space separated list of user IDs who you wanna assign as tiger users.

- `TIME_API_KEY` : Required for timezone information {`HW6LQCYX43HS`}

- `TOKEN` : Your bot token.

- `URL` : The Heroku App URL :- https://<appname>.herokuapp.com/

- `WEBHOOK` : Setting this to ANYTHING will enable webhooks.

- `WHITELIST_USERS` : A space separated list of user IDs who you want to assign as whitelisted - can't be banned with your bot.

# 𝐂𝐫𝐞𝐝𝐢𝐭𝐬
- [Thanks To Me ](https://github.com/PANDITHAN)
- Thanks To [Muhammed](https://github.com/PR0FESS0R-99)
- Thanks To [Lallu](https://github.com/Lallu-lallus) 
- Thanks To [CLaY995](https://github.com/CLaY9950) 
- Thanks To [ViruZs](https://github.com/TGExplore) 
- Thanks To [DudE Hacks](https://t.me/DudEhacks105) 


